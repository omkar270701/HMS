from django.shortcuts import render,HttpResponse, redirect
from datetime import datetime
from myapp.models import Contact
from django.contrib import messages
from myapp.models import Food
from myapp.models import Reservation
from django.contrib.auth.forms import UserCreationForm
from myapp.forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required





# Create your views here.

@login_required(login_url='loginpage')
def index(request):
    return render(request, 'index.html')
   
    #return HttpResponse("this is homepage")


def about(request):
    return render(request, 'about.html')
    #return HttpResponse("this is about page")

def services(request):
    return render(request, 'services.html')
    #return HttpResponse("this is service page")


def rooms(request):
    return render(request, 'room_detail_view.html')
    #return HttpResponse("this is rooms page")

def hireacar(request):
    return render(request, 'hireacar.html')
    #return HttpResponse("this is hireacar page")


def eve(request):
    return render(request, 'eve.html')

def menu(request):
    return render(request, 'menu.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('about')
    else:
        form= CreateUserForm()

        if request.method == 'POST':
            form= CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user=form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)
                return redirect('login')
        context={'form':form}
        return render(request, 'register.html', context)

def loginpage(request):
    if request.user.is_authenticated:
        return redirect('about')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('about')
            else:
                messages.info(request, 'Invalid Username or Password')
        return render(request, 'login.html')


def logoutUser(request):
    logout(request)
    messages.info(request, 'Logged Out Successfully')
    return render(request, 'login.html')


def contact(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact=Contact(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent succesfully!')
    return render(request, 'contact.html')
    #return HttpResponse("this is contact page")


def reservation(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        reservation=Reservation(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        reservation.save()
        messages.success(request, 'Your message has been sent succesfully!')
    return render(request,'reservation.html')

def food(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        food=Food(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        food.save()
        messages.success(request, 'Your message has been sent succesfully!')
    return render(request, 'food.html')
    #return HttpResponse("this is contact page")






    



