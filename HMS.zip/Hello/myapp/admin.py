from django.contrib import admin
from myapp.models import Contact
from myapp.models import Reservation
from myapp.models import Food

# Register your models here.
admin.site.register(Contact)
admin.site.register(Reservation)
admin.site.register(Food)


