#from django.contrib import admin
#from django.urls import path
#from hotel import views
#app_name='hotel'

#urlspatterns=[
    #path('room_list/', RoomList.as_view(), name='RoomList'),
    #path('booking_list/', BookingList.as_view(), name='BookingList'),
    #path("RoomListView", views.RoomListView, name='RoomListView'),
    #path("BookingList", views.BookingList, name='BookingList'),
    #path("BookingView", views.BookingView, name='BookingView'),
    #path('room/<category>', RoomDetailView.as_view(), name='RoomDetailView'),
    #path("RoomDetailView ", views.RoomDetailView, name='RoomDetailView'),
    
#]
from django.urls import path
from .views import RoomListView, BookingList, BookingView, RoomDetailView, CancelBookingView

app_name = 'hotel'

urlpatterns = [
    path('room_list/', RoomListView, name='RoomList'),
    path('booking_list/', BookingList.as_view(), name='BookingList'),
    path('book/', BookingView.as_view(), name='BookingView'),
    path('room/<category>', RoomDetailView.as_view(), name='RoomDetailView'),
    path('booking/cancel/<pk>', CancelBookingView.as_view(), name='CancelBookingView'),

]